INSERT INTO student (name, email, course) VALUES ('Ananya Rao', 'ananya@example.com', 'Computer Science');
INSERT INTO student (name, email, course) VALUES ('Rahul Kumar', 'rahul@example.com', 'Information Technology');
INSERT INTO student (name, email, course) VALUES ('Meera Shah', 'meera@example.com', 'Data Analytics');
