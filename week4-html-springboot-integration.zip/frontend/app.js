const API_URL = "http://localhost:8080/api/students";

const rows = document.getElementById("studentRows");
const form = document.getElementById("studentForm");
const message = document.getElementById("message");
const totalCount = document.getElementById("totalCount");
const connectionStatus = document.getElementById("connectionStatus");
const lastAction = document.getElementById("lastAction");
const submitBtn = document.getElementById("submitBtn");
const formTitle = document.getElementById("formTitle");
const studentId = document.getElementById("studentId");
const requestMethod = document.getElementById("requestMethod");
const cancelEditBtn = document.getElementById("cancelEditBtn");

function showMessage(text, type = "success") {
  message.textContent = text;
  message.className = `message show ${type}`;
}

function initials(name) {
  return name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase();
}

async function request(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });

  if (!response.ok) {
    let details = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      details = body.error || body.message || details;
    } catch (_) {}
    throw new Error(details);
  }

  if (response.status === 204) return null;
  return response.json();
}

async function loadStudents() {
  rows.innerHTML = '<tr><td colspan="4" class="empty">Loading students from API…</td></tr>';
  try {
    const students = await request(API_URL);
    connectionStatus.textContent = "Connected";
    connectionStatus.style.color = "#1b9a70";
    totalCount.textContent = students.length;
    lastAction.textContent = "GET request successful";
    renderStudents(students);
  } catch (error) {
    connectionStatus.textContent = "Offline";
    connectionStatus.style.color = "#c43f4c";
    totalCount.textContent = "—";
    rows.innerHTML = `<tr><td colspan="4" class="empty">Cannot connect to API. Start Spring Boot on port 8080.<br>${escapeHtml(error.message)}</td></tr>`;
    lastAction.textContent = "Check backend / CORS";
  }
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}

function renderStudents(students) {
  if (!students.length) {
    rows.innerHTML = '<tr><td colspan="4" class="empty">No students yet. Add one using the form.</td></tr>';
    return;
  }

  rows.innerHTML = students.map(student => `
    <tr>
      <td><div class="student-name"><span class="avatar">${escapeHtml(initials(student.name))}</span><span>${escapeHtml(student.name)}</span></div></td>
      <td>${escapeHtml(student.email)}</td>
      <td><span class="course-tag">${escapeHtml(student.course)}</span></td>
      <td><div class="row-actions">
        <button class="row-action" data-action="edit" data-id="${student.id}" type="button">Edit</button>
        <button class="row-action delete" data-action="delete" data-id="${student.id}" type="button">Delete</button>
      </div></td>
    </tr>`).join("");
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  const id = studentId.value;
  const payload = {
    name: document.getElementById("name").value.trim(),
    email: document.getElementById("email").value.trim(),
    course: document.getElementById("course").value.trim()
  };
  const isEdit = Boolean(id);
  submitBtn.disabled = true;
  submitBtn.textContent = isEdit ? "Saving…" : "Creating…";

  try {
    await request(isEdit ? `${API_URL}/${id}` : API_URL, {
      method: isEdit ? "PUT" : "POST",
      body: JSON.stringify(payload)
    });
    showMessage(isEdit ? "Student updated successfully." : "Student created successfully.");
    lastAction.textContent = `${isEdit ? "PUT" : "POST"} request successful`;
    resetForm();
    await loadStudents();
  } catch (error) {
    showMessage(error.message, "error");
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = studentId.value ? "Save changes" : "＋ Create student";
  }
});

rows.addEventListener("click", async event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const id = button.dataset.id;
  const action = button.dataset.action;

  if (action === "edit") {
    try {
      const student = await request(`${API_URL}/${id}`);
      studentId.value = student.id;
      document.getElementById("name").value = student.name;
      document.getElementById("email").value = student.email;
      document.getElementById("course").value = student.course;
      formTitle.textContent = "Edit student";
      submitBtn.textContent = "Save changes";
      requestMethod.textContent = `PUT /api/students/${id}`;
      cancelEditBtn.classList.remove("hidden");
      document.getElementById("name").focus();
    } catch (error) {
      showMessage(error.message, "error");
    }
  }

  if (action === "delete") {
    if (!confirm("Delete this student?")) return;
    try {
      await request(`${API_URL}/${id}`, { method: "DELETE" });
      showMessage("Student deleted successfully.");
      lastAction.textContent = "DELETE request successful";
      await loadStudents();
    } catch (error) {
      showMessage(error.message, "error");
    }
  }
});

function resetForm() {
  form.reset();
  studentId.value = "";
  formTitle.textContent = "Add a student";
  submitBtn.textContent = "＋ Create student";
  requestMethod.textContent = "POST /api/students";
  cancelEditBtn.classList.add("hidden");
}

cancelEditBtn.addEventListener("click", resetForm);
document.getElementById("refreshBtn").addEventListener("click", loadStudents);
loadStudents();
