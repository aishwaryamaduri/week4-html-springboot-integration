# Week 4 — HTML Frontend Integration

A simple vanilla HTML/CSS/JavaScript frontend that calls a Spring Boot REST API, renders students, and lets the user create a student.

## Project structure

```text
week4-html-springboot-integration/
├── backend/                         # Spring Boot API
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/example/week4/
│       │   ├── Week4Application.java
│       │   ├── Student.java
│       │   ├── StudentRepository.java
│       │   └── StudentController.java
│       └── resources/application.properties
├── frontend/
│   ├── index.html
│   ├── styles.css
│   └── app.js
└── README.md
```

## Requirements

- Java 17+
- Maven 3.9+ (or use the Maven wrapper if you add one)
- A browser
- Internet only if Maven needs to download dependencies

## Run the backend

Open a terminal in `backend/`:

```bash
mvn spring-boot:run
```

The API starts at `http://localhost:8080`.

Endpoints:
- `GET /api/students` — list students
- `GET /api/students/{id}` — fetch one student
- `POST /api/students` — create a student
- `PUT /api/students/{id}` — update a student
- `DELETE /api/students/{id}` — delete a student

The backend uses an H2 in-memory database, so sample data resets when the app restarts.

## Run the frontend

For reliable browser requests, serve the frontend from a local static server instead of opening the HTML as a `file://` URL.

From the project root, run:

```bash
python -m http.server 5500 --directory frontend
```

Then open `http://localhost:5500`.

Alternatively, use VS Code's Live Server extension on the `frontend/index.html` file.

## Demo flow

1. Start Spring Boot.
2. Open the frontend in your browser.
3. Click **Refresh** to load students from the API.
4. Enter a name, email, and course, then click **Create student**.
5. The frontend sends `POST /api/students`, then refreshes the list.
6. You can edit a row and click **Save** to demonstrate `PUT /api/students/{id}`.

## CORS

The controller allows requests from `http://localhost:5500` and `http://127.0.0.1:5500`. If your frontend runs on another port, update the `@CrossOrigin` origins in `StudentController.java`.

## Submission checklist

- Push the complete folder to a public GitHub repository.
- Record the browser and backend terminal showing GET and POST/PUT flow.
- Write a short LinkedIn post and tag `@SkillAudit.ai`.
- Do not claim a real screen recording until you have recorded the application running.
